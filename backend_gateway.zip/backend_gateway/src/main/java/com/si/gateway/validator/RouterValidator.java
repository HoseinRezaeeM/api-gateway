package com.si.gateway.validator;

import com.si.gateway.config.OpenApiEndpointsConfigProperties;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

@Component
public class RouterValidator {

    private final OpenApiEndpointsConfigProperties properties;

    @Autowired
    public RouterValidator(OpenApiEndpointsConfigProperties properties) {
        this.properties = properties;
    }

    public Boolean isSecured(ServerHttpRequest request) {

        List<String> startWiths = properties.getEndpoints()
                .stream().filter(s -> s.contains("/**"))
                .map(s -> s.replace("/**",""))
                .collect(Collectors.toList());

        boolean isNotSecure = startWiths.stream()
                .noneMatch(uri -> request.getURI().getPath().startsWith(uri));

        return isNotSecure && properties.getEndpoints()
                .stream()
                .noneMatch(uri -> request.getURI().getPath().contains(uri));
    }
}