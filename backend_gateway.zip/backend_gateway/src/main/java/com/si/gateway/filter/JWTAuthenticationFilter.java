package com.si.gateway.filter;

import com.si.gateway.validator.RouterValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.gateway.filter.GatewayFilter;
import org.springframework.cloud.gateway.filter.factory.GatewayFilterFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

@Component
public class JWTAuthenticationFilter implements GatewayFilterFactory<String> {

    private final JWTAuthenticationUtils utils;
    private final RouterValidator routerValidator;

    @Autowired
    public JWTAuthenticationFilter(JWTAuthenticationUtils utils, RouterValidator routerValidator) {
        this.utils = utils;
        this.routerValidator = routerValidator;
    }

    @Override
    public GatewayFilter apply(String config) {
        return ((exchange, chain) -> {
            ServerHttpRequest request = exchange.getRequest();
            if (routerValidator.isSecured(request)) {
                if (this.isAuthMissing(request))
                    return this.onError(exchange, "Authorization header is missing in request");

                final String bearerToken = this.getAuthHeader(request);

                if (!utils.validateToken(resolveToken(bearerToken)))
                    return this.onError(exchange, "Authorization header is invalid");

            }
            return chain.filter(exchange);
        });
    }

    @Override
    public Class<String> getConfigClass() {
        return String.class;
    }

    private Mono<Void> onError(ServerWebExchange exchange, String err) {
        ServerHttpResponse response = exchange.getResponse();
        response.setStatusCode(HttpStatus.UNAUTHORIZED);
        return response.setComplete();
    }

    private String getAuthHeader(ServerHttpRequest request) {
        return request.getHeaders().getOrEmpty("Authorization").get(0);
    }

    private String resolveToken(String bearerToken) {
        if (StringUtils.hasText(bearerToken) && bearerToken.startsWith("Bearer ")) {
            return bearerToken.substring(7);
        }
        return "";
    }

    private boolean isAuthMissing(ServerHttpRequest request) {
        return !request.getHeaders().containsKey("Authorization");
    }
}
