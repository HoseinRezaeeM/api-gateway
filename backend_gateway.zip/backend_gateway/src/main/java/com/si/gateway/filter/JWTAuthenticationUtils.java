package com.si.gateway.filter;

import com.si.security.jwt.TokenProvider;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Component;

@Component
@ComponentScan(basePackages = "com.si.security.jwt")
public class JWTAuthenticationUtils {

    private final TokenProvider tokenProvider;

    public JWTAuthenticationUtils() throws Exception {
        this.tokenProvider = new TokenProvider();
    }

    public boolean validateToken(String authToken) {
        try {
            return tokenProvider.validateToken(authToken);
        } catch (Exception e) {
            return false;
        }
    }
}
